import openmeteo_requests
import requests_cache
import pandas as pd
from retry_requests import retry
from datetime import datetime, timedelta
import numpy as np
import json  # to export weather data to js

# Setup the Open-Meteo API client with cache and retry on error
cache_session = requests_cache.CachedSession('.cache', expire_after=-1)
weather_client = openmeteo_requests.Client(session=cache_session)

def fetch_weather_today():
    # Define location coordinates
    latitude = -25.6083
    longitude = 27.8250

    # Initialize a list to store weather data
    weather_data_list = []

    # Set today's date and calculate the start date
    today = datetime.today().date()
    start_date = (today - timedelta(days=3)).strftime('%Y-%m-%d')
    end_date = today.strftime('%Y-%m-%d')

    # Define the API request parameters
    api_url = "https://archive-api.open-meteo.com/v1/archive"
    request_params = {
        "latitude": latitude,
        "longitude": longitude,
        "start_date": start_date,
        "end_date": end_date,
        "daily": [
            "wind_speed_10m_mean",
            "wind_gusts_10m_mean",
            "wind_direction_10m_dominant",
            "temperature_2m_mean",
            "precipitation_sum",
            "sunshine_duration",
            "relative_humidity_2m_mean"
        ],
        "timezone": "auto"
    }

    try:
        # Retrieve weather data for the past 3 days
        responses = weather_client.weather_api(api_url, params=request_params)

        if not responses:
            raise ValueError("No data received from the weather API.")

        # Process the response
        daily_data = responses[0].Daily()  # Access daily data

        # Create a formatted dictionary for the DataFrame
        formatted_data = {
            "Date": pd.date_range(
                start=pd.to_datetime(daily_data.Time(), unit="s", utc=True),
                end=pd.to_datetime(daily_data.TimeEnd(), unit="s", utc=True),
                freq=pd.Timedelta(seconds=daily_data.Interval()),
                inclusive="left"
            ).strftime('%Y-%m-%d'),
            "Average Wind Speed at 10m (km/h)": daily_data.Variables(0).ValuesAsNumpy(),
            "Average Wind Gusts at 10m (km/h)": daily_data.Variables(1).ValuesAsNumpy(),
            "Dominant Wind Direction at 10m (°)": daily_data.Variables(2).ValuesAsNumpy(),
            "Mean Temperature at 2m (°C)": daily_data.Variables(3).ValuesAsNumpy(),
            "Total Daily Precipitation (mm)": daily_data.Variables(4).ValuesAsNumpy(),
            "Daily Sunshine Duration (hours)": daily_data.Variables(5).ValuesAsNumpy(),
            "Average Relative Humidity at 2m (%)": daily_data.Variables(6).ValuesAsNumpy()
        }

        weather_dataframe = pd.DataFrame(data=formatted_data)  # Convert to DataFrame
        weather_data_list.append(weather_dataframe)

        print(f"Fetched data from {start_date} to {end_date}")

    except requests_cache.exceptions.RequestCacheError as e:
        print(f"Cache error: {e}")

    except retry.RetryError as e:
        print(f"Retry error: {e}")

    except ValueError as e:
        print(f"Value error: {e}")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    # Combine all fetched data into a single DataFrame if data was fetched
    if weather_data_list:
        combined_weather_data = pd.concat(weather_data_list, ignore_index=True, sort=False)

        # Calculate the average of each weather feature over the period
        precipitations = [np.mean(df['Total Daily Precipitation (mm)']) for df in weather_data_list]
        average_humiditys = [np.mean(df['Average Relative Humidity at 2m (%)']) for df in weather_data_list]
        average_sunshine_durations = [np.mean(df['Daily Sunshine Duration (hours)']) for df in weather_data_list]
        temperatures = [np.mean(df['Mean Temperature at 2m (°C)']) for df in weather_data_list]
        wind_speeds = [np.mean(df['Average Wind Speed at 10m (km/h)']) for df in weather_data_list]
        wind_gusts = [np.mean(df['Average Wind Gusts at 10m (km/h)']) for df in weather_data_list]

        # Use the circular mean for wind direction in degrees
        dominant_wind_directions = []
        for df in weather_data_list:
            wind_directions = df['Dominant Wind Direction at 10m (°)']
            circular_mean = np.arctan2(np.mean(np.sin(np.radians(wind_directions))),
                                       np.mean(np.cos(np.radians(wind_directions))))
            circular_mean_degrees = np.degrees(circular_mean) % 360
            dominant_wind_directions.append(circular_mean_degrees)

        # Determine the current season
        season = 'unknown'
        month = today.month
        if month in [12, 1, 2]:  # Summer
            season = 'Summer'
        elif month in [3, 4, 5]:  # Autumn
            season = 'Autumn'
        elif month in [6, 7, 8]:  # Winter
            season = 'Winter'
        else:  # Spring
            season = 'Spring'

        summary_data = {
            "Temperature": round(float(temperatures[0]), 2),
            "Wind Speed": round(float(wind_speeds[0]), 2),
            "Wind Gust": round(float(wind_gusts[0]), 2),
            "Wind Direction": round(float(dominant_wind_directions[0]), 2),
            "Season": season,
            "Precipitation": round(float(precipitations[0]), 2),
            "Humidity": round(float(average_humiditys[0]), 2),
            "Sunshine": round(float(average_sunshine_durations[0]), 2),
            "Start Date": start_date,
            "End Date": end_date
        }

        # Write summary data to JSON file in the data folder
        with open("./data/weather_today.json", "w") as json_file:
            json.dump(summary_data, json_file, indent=4)

        print("Data summary saved to ./data/weather_today.json.")

        return summary_data  # Return the summary data
    else:
        print("No weather data available to return.")
        return None  # Return None if no data was fetched

#fetch_weather_today()